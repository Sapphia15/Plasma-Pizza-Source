/**
 * Contains things in the foreground other than entities such as obstacles/walls/etc.
 */
/**
 * @author Keegan
 *
 */
package com.Foreground;